TRANSPORT COST CALCULATOR - Android application (Java, XML, SQLite)
Package: com.example.transportcost

HOW TO OPEN
Open this folder in Android Studio (File > Open), let Gradle sync, then Run.

PROJECT STRUCTURE
settings.gradle, build.gradle, gradle.properties,
gradle/wrapper/gradle-wrapper.properties ........ Configuration
app/build.gradle ................................ Module configuration
app/src/main/AndroidManifest.xml ................ Configuration (activities)

app/src/main/res/layout/ ........................ FRONT-END screens
    activity_main.xml (Q1), activity_input.xml (Q2),
    activity_results.xml (Q3), activity_splash.xml (Q4)
app/src/main/res/menu/menu_main.xml ............. FRONT-END Action Bar
app/src/main/res/values/ ........................ strings, colors, themes
app/src/main/res/drawable/ ...................... logo and help box border

app/src/main/java/com/example/transportcost/
    SplashActivity.java ......................... Q4 / Q11 splash screen
    Transport.java .............................. Q5 model class
    TransportCalculator.java .................... Q6 calculations
    Recommendation.java ......................... Q7 category and recommendation
    MainActivity.java ........................... Q8 home screen
    InputActivity.java .......................... Q9 validation and calculations
    ResultsActivity.java ........................ Q10 results screen
    DatabaseHelper.java ......................... DATABASE (SQLite)
    NavHelper.java .............................. Action Bar navigation
