package com.example.transportcost;

public class Recommendation {

    public static final String LOW_COST = "Low Cost";
    public static final String MODERATE = "Moderate";
    public static final String HIGH = "High";
    public static final String VERY_HIGH = "Very High";
    public static final String EXCESSIVE = "Excessive";

    public static String getCategory(double monthlyCost) {
        if (monthlyCost < 1000) {
            return LOW_COST;
        } else if (monthlyCost < 2000) {
            return MODERATE;
        } else if (monthlyCost < 3000) {
            return HIGH;
        } else if (monthlyCost < 5000) {
            return VERY_HIGH;
        } else {
            return EXCESSIVE;
        }
    }

    public static String getRecommendation(String category) {
        if (LOW_COST.equals(category)) {
            return "Continue using your current transport method.";
        } else if (MODERATE.equals(category)) {
            return "Consider carpooling where possible.";
        } else if (HIGH.equals(category)) {
            return "Reduce unnecessary trips and combine errands.";
        } else if (VERY_HIGH.equals(category)) {
            return "Consider public transport for regular commuting.";
        } else {
            return "Immediate action is recommended to reduce transport costs.";
        }
    }
}
