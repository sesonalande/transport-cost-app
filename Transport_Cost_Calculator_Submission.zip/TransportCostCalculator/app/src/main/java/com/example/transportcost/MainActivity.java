package com.example.transportcost;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private TextToSpeech tts;
    private boolean ttsReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnStart = findViewById(R.id.btnStart);
        Button btnListen = findViewById(R.id.btnListen);
        Button btnExit = findViewById(R.id.btnExit);

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(Locale.ENGLISH);
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA
                        && result != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });

        btnStart.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, InputActivity.class)));

        btnListen.setOnClickListener(v -> {
            if (ttsReady) {
                String text = getString(R.string.app_name) + ". "
                        + getString(R.string.welcome_message);
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "welcome");
            } else {
                Toast.makeText(this, R.string.msg_tts_not_ready,
                        Toast.LENGTH_SHORT).show();
            }
        });

        btnExit.setOnClickListener(v -> finishAffinity());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return NavHelper.handle(this, item) || super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStop() {
        if (tts != null) {
            tts.stop();
        }
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.shutdown();
        }
        super.onDestroy();
    }
}
