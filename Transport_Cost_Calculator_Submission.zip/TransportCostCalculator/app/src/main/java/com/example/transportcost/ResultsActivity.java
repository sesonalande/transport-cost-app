package com.example.transportcost;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ResultsActivity extends AppCompatActivity {

    public static final String EXTRA_ID = "transport_id";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);

        TextView tvMode = findViewById(R.id.tvMode);
        TextView tvType = findViewById(R.id.tvType);
        TextView tvDaily = findViewById(R.id.tvDailyCost);
        TextView tvMonthly = findViewById(R.id.tvMonthlyCost);
        TextView tvDistance = findViewById(R.id.tvMonthlyDistance);
        TextView tvCategory = findViewById(R.id.tvCategory);
        TextView tvRecommendation = findViewById(R.id.tvRecommendation);

        Button btnAgain = findViewById(R.id.btnCalculateAgain);
        Button btnExit = findViewById(R.id.btnExit);

        // 10a: Retrieve from the database
        DatabaseHelper db = new DatabaseHelper(this);
        long id = getIntent().getLongExtra(EXTRA_ID, -1);

        Transport t = (id == -1)
                ? db.getLatestTransport()
                : db.getTransportById(id);

        db.close();

        if (t == null) {
            Toast.makeText(this, R.string.msg_no_saved,
                    Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, InputActivity.class));
            finish();
            return;
        }

        // Display transport details
        tvMode.setText(getString(
                R.string.label_mode_result, t.getModeOfTransport()));

        tvType.setText(getString(
                R.string.label_type, t.getTransportType()));

        tvDaily.setText(getString(
                R.string.label_daily_cost, t.getDailyCost()));

        tvMonthly.setText(getString(
                R.string.label_monthly_cost, t.getMonthlyCost()));

        tvDistance.setText(getString(
                R.string.label_monthly_distance, t.getMonthlyDistance()));

        // 10b: Determine transport cost category using conditional statements
        double monthlyCost = t.getMonthlyCost();
        String category;

        if (monthlyCost < 1000) {
            category = Recommendation.LOW_COST;
        } else if (monthlyCost < 2000) {
            category = Recommendation.MODERATE;
        } else if (monthlyCost < 3000) {
            category = Recommendation.HIGH;
        } else if (monthlyCost < 5000) {
            category = Recommendation.VERY_HIGH;
        } else {
            category = Recommendation.EXCESSIVE;
        }

        tvCategory.setText(getString(R.string.label_category, category));

        // 10c: Display recommendation
        tvRecommendation.setText(getString(
                R.string.label_recommendation,
                Recommendation.getRecommendation(category)));

        // Navigation buttons
        btnAgain.setOnClickListener(v -> {
            startActivity(new Intent(this, InputActivity.class));
            finish();
        });

        btnExit.setOnClickListener(v -> finishAffinity());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return NavHelper.handle(this, item) || super.onOptionsItemSelected(item);
    }
}
