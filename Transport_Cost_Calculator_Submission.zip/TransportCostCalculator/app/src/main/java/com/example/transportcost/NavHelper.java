package com.example.transportcost;

import android.app.Activity;
import android.content.Intent;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

public class NavHelper {

    public static boolean handle(Activity activity, MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_home) {
            Intent intent = new Intent(activity, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            activity.startActivity(intent);
            return true;

        } else if (id == R.id.action_details) {
            if (!(activity instanceof InputActivity)) {
                activity.startActivity(new Intent(activity, InputActivity.class));
            }
            return true;

        } else if (id == R.id.action_reports) {
            DatabaseHelper db = new DatabaseHelper(activity);
            Transport latest = db.getLatestTransport();
            db.close();

            if (latest == null) {
                Toast.makeText(activity, R.string.msg_no_saved,
                        Toast.LENGTH_LONG).show();
            } else if (!(activity instanceof ResultsActivity)) {
                Intent intent = new Intent(activity, ResultsActivity.class);
                intent.putExtra(ResultsActivity.EXTRA_ID, latest.getId());
                activity.startActivity(intent);
            }
            return true;

        } else if (id == R.id.action_help) {
            new AlertDialog.Builder(activity)
                    .setTitle(R.string.help_title)
                    .setMessage(R.string.help_text)
                    .setPositiveButton(R.string.btn_ok, null)
                    .show();
            return true;
        }

        return false;
    }
}
