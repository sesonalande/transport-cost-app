package com.example.transportcost;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "transport.db";
    private static final int DB_VERSION = 1;

    public static final String TABLE = "transport";
    public static final String COL_ID = "id";
    public static final String COL_MODE = "mode_of_transport";
    public static final String COL_TYPE = "transport_type";
    public static final String COL_DATE = "travel_date";
    public static final String COL_DISTANCE = "distance_per_day";
    public static final String COL_COST_KM = "cost_per_km";
    public static final String COL_DAYS = "travel_days";
    public static final String COL_DAILY = "daily_cost";
    public static final String COL_MONTHLY = "monthly_cost";
    public static final String COL_MONTHLY_DIST = "monthly_distance";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE + " ("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_MODE + " TEXT NOT NULL, "
                + COL_TYPE + " TEXT NOT NULL, "
                + COL_DATE + " TEXT, "
                + COL_DISTANCE + " REAL, "
                + COL_COST_KM + " REAL, "
                + COL_DAYS + " INTEGER, "
                + COL_DAILY + " REAL, "
                + COL_MONTHLY + " REAL, "
                + COL_MONTHLY_DIST + " REAL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE);
        onCreate(db);
    }

    public long insertTransport(Transport t) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_MODE, t.getModeOfTransport());
        values.put(COL_TYPE, t.getTransportType());
        values.put(COL_DATE, t.getTravelDate());
        values.put(COL_DISTANCE, t.getDistancePerDay());
        values.put(COL_COST_KM, t.getCostPerKm());
        values.put(COL_DAYS, t.getTravelDays());
        values.put(COL_DAILY, t.getDailyCost());
        values.put(COL_MONTHLY, t.getMonthlyCost());
        values.put(COL_MONTHLY_DIST, t.getMonthlyDistance());

        return db.insert(TABLE, null, values);
    }

    public Transport getTransportById(long id) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor c = db.query(TABLE, null, COL_ID + " = ?",
                new String[]{String.valueOf(id)}, null, null, null);

        return readFirst(c);
    }

    public Transport getLatestTransport() {
        SQLiteDatabase db = getReadableDatabase();

        Cursor c = db.query(TABLE, null, null, null, null, null,
                COL_ID + " DESC", "1");

        return readFirst(c);
    }

    private Transport readFirst(Cursor c) {
        Transport t = null;

        try {
            if (c.moveToFirst()) {
                t = new Transport(
                        c.getString(c.getColumnIndexOrThrow(COL_MODE)),
                        c.getString(c.getColumnIndexOrThrow(COL_TYPE)),
                        c.getString(c.getColumnIndexOrThrow(COL_DATE)),
                        c.getDouble(c.getColumnIndexOrThrow(COL_DISTANCE)),
                        c.getDouble(c.getColumnIndexOrThrow(COL_COST_KM)),
                        c.getInt(c.getColumnIndexOrThrow(COL_DAYS)));

                t.setId(c.getLong(c.getColumnIndexOrThrow(COL_ID)));
                t.setDailyCost(c.getDouble(c.getColumnIndexOrThrow(COL_DAILY)));
                t.setMonthlyCost(c.getDouble(c.getColumnIndexOrThrow(COL_MONTHLY)));
                t.setMonthlyDistance(c.getDouble(
                        c.getColumnIndexOrThrow(COL_MONTHLY_DIST)));
            }
        } finally {
            c.close();
        }

        return t;
    }
}
