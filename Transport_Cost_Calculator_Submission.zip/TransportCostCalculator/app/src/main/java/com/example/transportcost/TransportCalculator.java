package com.example.transportcost;

public class TransportCalculator {

    // Daily Cost = Distance per Day x Cost per Kilometre
    public static double calculateDailyCost(double distancePerDay, double costPerKm) {
        return distancePerDay * costPerKm;
    }

    // Monthly Cost = Daily Cost x Travel Days
    public static double calculateMonthlyCost(double dailyCost, int travelDays) {
        return dailyCost * travelDays;
    }

    // Monthly Distance = Distance per Day x Travel Days
    public static double calculateMonthlyDistance(double distancePerDay, int travelDays) {
        return distancePerDay * travelDays;
    }
}
