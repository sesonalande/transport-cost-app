package com.example.transportcost;

public class Transport {

    private long id;
    private String modeOfTransport;
    private String transportType;
    private String travelDate;
    private double distancePerDay;
    private double costPerKm;
    private int travelDays;
    private double dailyCost;
    private double monthlyCost;
    private double monthlyDistance;

    public Transport() {
    }

    public Transport(String modeOfTransport, String transportType, String travelDate,
                     double distancePerDay, double costPerKm, int travelDays) {
        this.modeOfTransport = modeOfTransport;
        this.transportType = transportType;
        this.travelDate = travelDate;
        this.distancePerDay = distancePerDay;
        this.costPerKm = costPerKm;
        this.travelDays = travelDays;
    }

    public long getId() { return id; }
    public String getModeOfTransport() { return modeOfTransport; }
    public String getTransportType() { return transportType; }
    public String getTravelDate() { return travelDate; }
    public double getDistancePerDay() { return distancePerDay; }
    public double getCostPerKm() { return costPerKm; }
    public int getTravelDays() { return travelDays; }
    public double getDailyCost() { return dailyCost; }
    public double getMonthlyCost() { return monthlyCost; }
    public double getMonthlyDistance() { return monthlyDistance; }

    public void setId(long id) { this.id = id; }
    public void setModeOfTransport(String modeOfTransport) { this.modeOfTransport = modeOfTransport; }
    public void setTransportType(String transportType) { this.transportType = transportType; }
    public void setTravelDate(String travelDate) { this.travelDate = travelDate; }
    public void setDistancePerDay(double distancePerDay) { this.distancePerDay = distancePerDay; }
    public void setCostPerKm(double costPerKm) { this.costPerKm = costPerKm; }
    public void setTravelDays(int travelDays) { this.travelDays = travelDays; }
    public void setDailyCost(double dailyCost) { this.dailyCost = dailyCost; }
    public void setMonthlyCost(double monthlyCost) { this.monthlyCost = monthlyCost; }
    public void setMonthlyDistance(double monthlyDistance) { this.monthlyDistance = monthlyDistance; }
}
