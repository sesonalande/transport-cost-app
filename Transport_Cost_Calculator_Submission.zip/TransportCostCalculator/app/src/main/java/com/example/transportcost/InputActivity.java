package com.example.transportcost;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;
import java.util.Locale;

public class InputActivity extends AppCompatActivity {

    private EditText etMode, etDistance, etCostPerKm, etTravelDays;
    private Spinner spinnerType;
    private DatePicker datePicker;

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input);

        dbHelper = new DatabaseHelper(this);

        etMode = findViewById(R.id.etMode);
        etDistance = findViewById(R.id.etDistance);
        etCostPerKm = findViewById(R.id.etCostPerKm);
        etTravelDays = findViewById(R.id.etTravelDays);

        spinnerType = findViewById(R.id.spinnerType);
        datePicker = findViewById(R.id.datePicker);

        Button btnCalculateSave = findViewById(R.id.btnCalculateSave);
        Button btnClear = findViewById(R.id.btnClear);

        btnCalculateSave.setOnClickListener(v -> calculateAndSave());
        btnClear.setOnClickListener(v -> clearFields());
    }

    private void showInvalidDialog() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.dialog_invalid_title)
                .setMessage(R.string.dialog_invalid_msg)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setPositiveButton(R.string.btn_ok, null)
                .show();
    }

    private void calculateAndSave() {

        // 9a: Read input values
        String mode = etMode.getText().toString().trim();
        String distanceStr = etDistance.getText().toString().trim();
        String costStr = etCostPerKm.getText().toString().trim();
        String daysStr = etTravelDays.getText().toString().trim();
        String type = spinnerType.getSelectedItem().toString();

        // Validate empty fields
        if (mode.isEmpty() || distanceStr.isEmpty() || costStr.isEmpty() || daysStr.isEmpty()) {
            showInvalidDialog();
            return;
        }

        double distance;
        double costPerKm;
        int travelDays;

        // Validate numeric values
        try {
            distance = Double.parseDouble(distanceStr);
            costPerKm = Double.parseDouble(costStr);
            travelDays = Integer.parseInt(daysStr);
        } catch (NumberFormatException e) {
            showInvalidDialog();
            return;
        }

        // Validate positive and reasonable values
        if (Double.isNaN(distance) || Double.isInfinite(distance) || distance <= 0
                || Double.isNaN(costPerKm) || Double.isInfinite(costPerKm) || costPerKm <= 0
                || travelDays < 1 || travelDays > 31) {
            showInvalidDialog();
            return;
        }

        // 9b: Read the selected date
        String travelDate = String.format(Locale.US, "%04d-%02d-%02d",
                datePicker.getYear(),
                datePicker.getMonth() + 1,
                datePicker.getDayOfMonth());

        // Create Transport object
        Transport transport = new Transport(
                mode, type, travelDate, distance, costPerKm, travelDays);

        // Calculate transport costs
        double dailyCost =
                TransportCalculator.calculateDailyCost(distance, costPerKm);

        double monthlyCost =
                TransportCalculator.calculateMonthlyCost(dailyCost, travelDays);

        double monthlyDistance =
                TransportCalculator.calculateMonthlyDistance(distance, travelDays);

        // Store calculated values in the object
        transport.setDailyCost(dailyCost);
        transport.setMonthlyCost(monthlyCost);
        transport.setMonthlyDistance(monthlyDistance);

        // Save calculation in SQLite database
        long rowId = dbHelper.insertTransport(transport);

        if (rowId == -1) {
            Toast.makeText(this,
                    "Could not save the calculation. Please try again.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        Toast.makeText(this, R.string.msg_saved, Toast.LENGTH_SHORT).show();

        // Open Results screen
        Intent intent = new Intent(this, ResultsActivity.class);
        intent.putExtra(ResultsActivity.EXTRA_ID, rowId);
        startActivity(intent);
    }

    private void clearFields() {

        etMode.setText("");
        etDistance.setText("");
        etCostPerKm.setText("");
        etTravelDays.setText("");

        spinnerType.setSelection(0);

        // Reset DatePicker to today's date
        Calendar cal = Calendar.getInstance();

        datePicker.updateDate(
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH));

        etMode.requestFocus();

        Toast.makeText(this, R.string.msg_cleared,
                Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return NavHelper.handle(this, item) || super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}
