import com.example.transportcost.*;
import java.util.Locale;

public class RunTests {
    static int pass = 0, fail = 0;

    static void test(int no, String name, String mode, String type, double dist, double rate, int days,
                     double expDaily, double expMonthly, double expKm, String expCat, String expRec) {
        Transport t = new Transport(mode, type, "2026-11-18", dist, rate, days);
        double daily = TransportCalculator.calculateDailyCost(dist, rate);
        double monthly = TransportCalculator.calculateMonthlyCost(daily, days);
        double km = TransportCalculator.calculateMonthlyDistance(dist, days);
        t.setDailyCost(daily); t.setMonthlyCost(monthly); t.setMonthlyDistance(km);
        String cat = Recommendation.getCategory(t.getMonthlyCost());
        String rec = Recommendation.getRecommendation(cat);
        boolean ok = Math.abs(daily - expDaily) < 0.005 && Math.abs(monthly - expMonthly) < 0.005
                && Math.abs(km - expKm) < 0.005 && cat.equals(expCat) && rec.equals(expRec);
        if (ok) pass++; else fail++;
        System.out.println("TEST " + no + ": " + name);
        System.out.println("  INPUT   Mode of Transport : " + t.getModeOfTransport());
        System.out.println("          Transport Type    : " + t.getTransportType());
        System.out.println("          Distance per Day  : " + dist + " km");
        System.out.println("          Cost per Kilometre: R" + String.format(Locale.US, "%.2f", rate));
        System.out.println("          Travel Days       : " + days);
        System.out.println("  OUTPUT  Daily Transport Cost       : R" + String.format(Locale.US, "%,.2f", t.getDailyCost()));
        System.out.println("          Monthly Transport Cost     : R" + String.format(Locale.US, "%,.2f", t.getMonthlyCost()));
        System.out.println("          Monthly Distance Travelled : " + String.format(Locale.US, "%,.1f", t.getMonthlyDistance()) + " km");
        System.out.println("          Transport Cost Category    : " + cat);
        System.out.println("          Recommendation             : " + rec);
        System.out.println("  EXPECTED R" + expDaily + " / R" + expMonthly + " / " + expKm + " km / " + expCat);
        System.out.println("  RESULT  " + (ok ? "PASS" : "FAIL"));
        System.out.println();
    }

    static void boundary(double monthly, String expCat) {
        String cat = Recommendation.getCategory(monthly);
        boolean ok = cat.equals(expCat);
        if (ok) pass++; else fail++;
        System.out.println(String.format(Locale.US, "  R%,10.2f -> %-10s (expected %-10s) %s", monthly, cat, expCat, ok ? "PASS" : "FAIL"));
    }

    public static void main(String[] a) {
        System.out.println("TRANSPORT COST CALCULATOR - LOGIC TEST RUN");
        System.out.println("Classes tested: Transport, TransportCalculator, Recommendation (compiled from the project source)");
        System.out.println("Run date: " + java.time.LocalDateTime.now().withNano(0));
        System.out.println("Java: " + System.getProperty("java.version"));
        System.out.println("============================================================\n");

        String LOW = "Continue using your current transport method.";
        String MOD = "Consider carpooling where possible.";
        String HIGH = "Reduce unnecessary trips and combine errands.";
        String VH = "Consider public transport for regular commuting.";
        String EX = "Immediate action is recommended to reduce transport costs.";

        test(1, "Typical commute (High)", "Daily commute", "Taxi", 20, 5.00, 20, 100, 2000, 400, "High", HIGH);
        test(2, "Low cost commute", "Bus to work", "Bus", 10, 2.00, 20, 20, 400, 200, "Low Cost", LOW);
        test(3, "Moderate commute", "Train to campus", "Train", 25, 3.00, 20, 75, 1500, 500, "Moderate", MOD);
        test(4, "Very High commute", "Own car", "Private Vehicle", 60, 2.50, 22, 150, 3300, 1320, "Very High", VH);
        test(5, "Excessive commute", "Own car", "Private Vehicle", 100, 4.00, 20, 400, 8000, 2000, "Excessive", EX);
        test(6, "Decimal values", "Motorbike", "Motorcycle", 12.5, 1.80, 22, 22.5, 495, 275, "Low Cost", LOW);
        test(7, "Maximum travel days", "Own car", "Private Vehicle", 50, 12.50, 30, 625, 18750, 1500, "Excessive", EX);

        System.out.println("CATEGORY BOUNDARY CHECKS (monthly cost -> category)");
        boundary(0, "Low Cost");
        boundary(999.99, "Low Cost");
        boundary(1000, "Moderate");
        boundary(1999.99, "Moderate");
        boundary(2000, "High");
        boundary(2999.99, "High");
        boundary(3000, "Very High");
        boundary(4999.99, "Very High");
        boundary(5000, "Excessive");
        boundary(12000, "Excessive");

        System.out.println("\n============================================================");
        System.out.println("SUMMARY: " + pass + " passed, " + fail + " failed");
    }
}
